document.getElementById("menu").outerHTML = "";
document.getElementById("article").style.left = "0px";
document.getElementById("article").style.marginLeft = "0px";
document.getElementById("article").style.width = "100%";
document.getElementsByTagName("body")[0].style.width = "100%";

